---
name: HyperHex Light
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#3d484e'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#6d797f'
  outline-variant: '#bcc8d0'
  surface-tint: '#006684'
  primary: '#006684'
  on-primary: '#ffffff'
  primary-container: '#15b6e8'
  on-primary-container: '#004358'
  inverse-primary: '#6ad3ff'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2e1'
  on-secondary-container: '#656464'
  tertiary: '#885200'
  on-tertiary: '#ffffff'
  tertiary-container: '#ea9629'
  on-tertiary-container: '#5b3500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bee9ff'
  primary-fixed-dim: '#6ad3ff'
  on-primary-fixed: '#001f2a'
  on-primary-fixed-variant: '#004d65'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c9c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#ffdcbb'
  tertiary-fixed-dim: '#ffb86a'
  on-tertiary-fixed: '#2c1700'
  on-tertiary-fixed-variant: '#683d00'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
typography:
  display-lg:
    fontFamily: Anybody
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Anybody
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Anybody
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Anybody
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  code:
    fontFamily: DM Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.4'
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The design system embodies a high-end technical aesthetic, blending the precision of a 3D design studio with a clean, minimalist professional interface. It targets creators and engineers who value structural integrity and digital craftsmanship. 

The visual language is defined by **Technical Minimalism**. It utilizes a "faceted" geometric motif, where 45-degree angled corners replace traditional rounded or sharp edges to simulate industrial machining. The UI should evoke a sense of physical depth through subtle layered shadows and precise alignment, maintaining a premium, airy feel through generous whitespace and an off-white foundation.

## Colors

The palette is anchored by an off-white neutral base to reduce eye strain while maintaining a high-end "gallery" feel. 

- **Primary (Accent):** HyperHex Cyan (#15b6e8) is used sparingly for interactive states, progress indicators, and primary call-to-actions.
- **Surface & Background:** The main canvas is #f5f6f7, while elevated components (cards, modals) use pure #ffffff to create a clear "object" hierarchy.
- **Typography:** Headlines and critical UI labels utilize #0a0a0a for maximum contrast. Supporting information and metadata use #6b7280.
- **State Colors:** Success, Warning, and Error states should be desaturated to match the technical tone, avoiding overly vibrant palettes that distract from the 3D aesthetic.

## Typography

This design system uses a dual-type strategy to balance expressive branding with functional utility.

- **Headlines:** Use *Anybody* (serving as the substitute for Zalando Sans Expanded) for all primary headings. It should be used in Bold or ExtraBold weights with tight tracking to emphasize the technical, architectural feel.
- **Body & UI:** *DM Sans* provides a neutral, highly legible contrast. It is used for all long-form text, input fields, and navigational elements.
- **Hierarchy:** Maintain a clear distinction between the "expressive" headings and "functional" body. Labels should often be set in medium weight with slight letter spacing for a clean, data-driven appearance.

## Layout & Spacing

The layout philosophy follows a **Structural Grid** model. 

- **Grid:** A 12-column fluid grid for desktop with 24px gutters. For mobile, transition to a 4-column grid with 16px margins.
- **Rhythm:** All vertical and horizontal spacing must be multiples of 4px. Use 16px (md) for standard internal padding and 24px (lg) for section separation.
- **Alignment:** Elements should feel "snapped" to the grid. Use hard-aligned edges to reinforce the technical studio vibe.

## Elevation & Depth

Depth is achieved through **Subtle Ambient Shadows** rather than heavy blurs. 

- **Shadow Profile:** Shadows should be sharp and slightly offset on the Y-axis (e.g., `0px 4px 12px rgba(0, 0, 0, 0.05)`).
- **Layering:** Use a three-tier system:
    1. **Level 0 (Base):** #f5f6f7 (Background).
    2. **Level 1 (Card):** #ffffff with a 1px border (#e5e7eb) and a soft shadow.
    3. **Level 2 (Active/Float):** #ffffff with a more pronounced shadow and a Cyan (#15b6e8) accent border.
- **Faceted Shadows:** Avoid shadows on the 45-degree chamfered corners if possible, or ensure the shadow follows the geometric clipping path of the element.

## Shapes

The defining characteristic of this design system is the **Faceted Corner**. 

- **Chamfer Logic:** All interactive containers, buttons, and input fields must feature 45-degree "clipped" corners. 
- **Standard Clip:** 8px for large containers (cards), 4px for smaller elements (buttons, chips).
- **Radius:** Standard `border-radius` is 0px. The visual "roundness" is replaced entirely by these geometric cuts.
- **Borders:** Use 1px solid borders in #e5e7eb for most containers to define their edges against the off-white background.

## Components

- **Buttons:** Primary buttons use the Cyan accent with white text and 4px faceted corners. Secondary buttons use a white background with a 1px near-black border. 
- **Input Fields:** Rectangular with clipped top-right and bottom-left corners. Use #ffffff backgrounds and 1px #6b7280 borders that turn Cyan on focus.
- **Cards:** White surfaces with 8px faceted corners. Headers within cards should be separated by a subtle 1px horizontal rule.
- **Chips/Labels:** Small, 4px clipped shapes. Use a light cyan tint (#e1f5fe) for active states and #f5f6f7 for neutral states.
- **Navigation:** Top-bar navigation should be sticky with a subtle bottom shadow. Use *DM Sans* medium for menu items, transitioning to Cyan on hover.
- **3D Viewport/Containers:** When displaying technical content, use a "recessed" look with an inner shadow and a darker gray (#eaebec) background to simulate a studio stage.